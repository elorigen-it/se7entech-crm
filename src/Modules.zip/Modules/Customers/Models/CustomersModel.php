<?php
namespace Se7entech\Contractnew\Modules\Customers\Models;

class CustomersModel{
    private static $newTable = 'customers';
    private static $tables = array('clients', 'colleges', 'lead');
    private static $mapfields = array(
        'clients' => array(
            'id' => 'id',
            'name' => 'name',
            'business_name' => 'businessname',
            'email' => 'email',
            'phone' => 'phone'
        ),
        'colleges' => array(
            'id' => 'id',
            'name' => 'client_name',
            'business_name' => 'client_name',
            'email' => 'email',
            'phone' => 'phone'
        ),
        'lead' => array(
            'id' => 'id',
            'name' => 'name',
            'business_name' => 'businessname',
            'email' => 'email',
            'phone' => 'phone'
        )
    );
    private static $finalfields = array(
        'id', 'name', 'business_name', 'email', 'phone'
    );

    public static function getCustomersFromAgent($email){
        include __DIR__ . '/../../../../config/connection.php';
        
        $sql = "SELECT * FROM ". self::$newTable ." WHERE agent_email='$email'";
        $res = mysqli_query($con, $sql);
        if(mysqli_num_rows($res)){
            $response = array();
            while($row = mysqli_fetch_assoc($res)){
                $response[] = $row;
            }
        }  
        return $response;
    }
    public static function getAll(){
        include __DIR__ . '/../../../../config/connection.php';
        $response = array();

        foreach(self::$tables as $table){
            $response[$table] = array();
            $sql = "SELECT ";
            $iteration = 0;
            foreach(self::$mapfields[$table] as $field => $value){
                $sql .= $value;
                if($iteration < (count(self::$mapfields[$table]) - 1)){
                    $sql .= ', ';
                }
                $iteration++;
            }
            $sql .= " FROM " . $table;
            $res = mysqli_query($con, $sql);

            if(mysqli_num_rows($res)){
                while($row = mysqli_fetch_assoc($res)){
                    array_push($response[$table], self::normalizeFields($table, $row));
                }
            }          
        }
        
        return $response;
    }

    public static function getAllV2(){
        include __DIR__ . '/../../../../config/connection.php';
        $response = array();

        $sql = "SELECT * FROM ". self::$newTable;
        $res = mysqli_query($con, $sql);
        if(mysqli_num_rows($res)){
            $response = array();
            while($row = mysqli_fetch_assoc($res)){
                $response[] = $row;
            }
        }  
        return $response;
        
    }
    
    public static function getCustomer($table, $id){
        include __DIR__ . '/../../../../config/connection.php';
        $response = array();
        $sql = "SELECT * FROM $table WHERE id='$id'";
        $res = mysqli_query($con, $sql);
        
        if(mysqli_num_rows($res)){
            while($row = mysqli_fetch_assoc($res)){
                $response = self::normalizeFields($table, $row);
            }
        }  
        return $response;
    }

    public static function mapFields($table, $field){
        return self::$mapfields[$table][$field];
    }

    public static function normalizeFields($table, $row){
        $res = array();
        foreach(self::$finalfields as $field ){
            $res[$field] = $row[self::mapFields($table, $field)];
        }
        return $res;
    }
}