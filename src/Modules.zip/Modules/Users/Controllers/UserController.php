<?php

namespace Se7entech\Contractnew\Modules\Users\Controllers;

use Se7entech\Contractnew\Modules\Roles\Models\RolesModel;
use Se7entech\Contractnew\Modules\Zones\Models\ZonesModel;
use Se7entech\Contractnew\Modules\Users\Models\UserModel;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use Rakit\Validation\Validator;
use Se7entech\Contractnew\Helpers\UniqueRule;
use Se7entech\Contractnew\Helpers\Mailer;


class UserController{
    public $data = array(
        'errors' => array(),
        'last_data' => array(),
        'current' => array(),
        'success' => null,
        'session' => array(),
        'roles' => array(),
        'zones' => array()
    );

    public function __construct(Session $session){
        global $base_url;
        $this->base_url = $base_url;
        $this->session = $session;
        $this->session->set('access', $_SESSION['access']);
        $this->session->set('user', $_SESSION['user']);
        $this->session->set('email', $_SESSION['email']);
        $this->session->set('designation', $_SESSION['designation']);
        $this->session->set('zone_id', $_SESSION['zone_id']);

        $this->data['users'] = $this->getUsers();
        foreach ($this->session->getFlashBag()->all() as $type => $messages) {
            if($type === 'last_data'){
                $this->data['last_data'] = $messages[0];
                continue;
            }
            if($type === 'current'){
                $this->data['current'] = $messages[0];
                continue;
            }
            foreach($messages as $message){
                array_push($this->data['session'], '<div class="alert alert-'.$type.' p-2" role="alert">'.$message.'</div>');
            }
        }
        $this->data['roles'] = RolesModel::getAll();
        $this->data['zones'] = ZonesModel::getAll();

    }
    public function index(){
        include __DIR__ . '/../index.php';
    }

    public function getById($params){
        $id = $params['id'];
        if($id){
            $record = UserModel::getById($id);
            if($record){
                $this->data['current'] = $record;
                include __DIR__ . '/../single.php';
            }else{
                $flashes = $this->session->getFlashBag();
                $flashes->add('warning', 'User id not found');

                header('location: ' . $this->base_url . '/modules/users/');
            }  
        }else{
            $flashes = $this->session->getFlashBag();
            $flashes->add('warning', 'Bad Request');
            header('location: ' . $this->base_url . '/modules/users/');
        }
    }
    
    public function postUser(){

        $request = Request::createFromGlobals();
        if($request->request->get('save')){
            $validation = $this->_validateData($request->request->all());

            if ($validation->fails()) {
                // handling errors
                $errors = $validation->errors();
                $this->data['errors'] = $errors;
                $messages = $errors->all('<span>:message</span>');
                $flashes = $this->session->getFlashBag();
                // add flash messages
                foreach($messages as $msg){
                    $flashes->add(
                        'danger',
                        $msg
                    );
                }
                $flashes->add('last_data', $request->request->all());
        
            }else{
                $digits = 4;
                $otp = rand(pow(10, $digits-1), pow(10, $digits)-1);
                $postData = $request->request->all();
                $postData['password'] = $otp;
                $postData['avatar'] = $this->base_url . '/uploads/avatars/default.png';

    
                if($_FILES['avatar']['size']){
                    $fullname=$_FILES['avatar']['name']; 
                    $name=explode('.',$fullname);
                    $ext=$name[1];
                    $date = date('m/d/Yh:i:sa', time());
                    $rand=rand(10000,99999);
                    $encname=$date.$rand;
                    $finalname=md5($encname).'.'.$ext;
                    $path = "/uploads/avatars/".$finalname;
                    $finalpath=$base_path . $path;
                    move_uploaded_file($_FILES["avatar"]["tmp_name"],$finalpath);

                    $postData['avatar'] = $this->base_url . $path;
                }

                $res = UserModel::postUser($postData);
                $flashes = $this->session->getFlashBag();
                if($res){
                    $this->data['success'] = true;
                    $flashes->add(
                        'success',
                        '<span>New User created</span>'
                    );
                    $user = $this->session->get('user');
                    $designation = $this->session->get('designation');

                    $content = file_get_contents(__DIR__ . '/../welcome-template.html');
                    $content = str_replace(array('%base_url%', '%username%', '%password%', '%agent_name%', '%smtp_user%', '%smtp_pass%'), array($this->base_url, $postData['email'], $otp, $user, $postData['smtp_user'], $postData['smtp_pass']), $content);
                    // TODO: send password to email. 
                    // $from, $fromName, $to, $toName, $subject, $content, $altContent
                    $from = 'webmaster1@se7entech.net';
                    $fromName = 'Se7entech LLC';
                    $to = $postData['email'];
                    $toName = $postData['firstname'] . ' ' . $postData['lastname'];
                    $subject = 'Welcome to Se7entech!';
        
                    $mailer = new Mailer($from, $fromName, $to, $toName, $subject, $content);
                    $mailer->send();

                }else{
                    $this->data['success'] = false;
                    $flashes->add(
                        'warning',
                        '<span>Something happened with database</span>'
                    );
                }
            }

            header('location: ' . $this->base_url . '/modules/users/');
        }
    }

    public function updateUser($params){
        
        $request = Request::createFromGlobals();
        $id = $params['id'];
        $user = UserModel::getById($id);
        
        if($request->request->get('save')){
            $postData = $request->request->all();
            unset($postData['email']);
            $validation = $this->_validateDataToUpdate($postData);
            if ($validation->fails()) {
                // handling errors
                $errors = $validation->errors();
                $this->data['errors'] = $errors;
                $messages = $errors->all('<span>:message</span>');
                $flashes = $this->session->getFlashBag();
                // add flash messages
                foreach($messages as $msg){
                    $flashes->add(
                        'danger',
                        $msg
                    );
                }
                $flashes->add('current', $request->request->all());
            }else{
                $postData = $request->request->all();
                $postData['avatar'] = $user['avatar'];

                if($_FILES['avatar']['size']){
                    $fullname=$_FILES['avatar']['name']; 
                    $name=explode('.',$fullname);
                    $ext=$name[1];
                    $date = date('m/d/Yh:i:sa', time());
                    $rand=rand(10000,99999);
                    $encname=$date.$rand;
                    $finalname=md5($encname).'.'.$ext;
                    $path = "/uploads/avatars/".$finalname;
                    $finalpath=$base_path . $path;
                    move_uploaded_file($_FILES["avatar"]["tmp_name"],$finalpath);

                    $postData['avatar'] = $this->base_url . $path;
                }

                $res = UserModel::update($id, $postData);
                $flashes = $this->session->getFlashBag();
                if($res){
                    $this->data['success'] = true;
                    $flashes->add(
                        'success',
                        '<span>User updated</span>'
                    );
                }else{
                    $this->data['success'] = false;
                    $flashes->add(
                        'warning',
                        '<span>Something happened with database</span>'
                    );
                }
            }

            header('location: ' . $this->base_url . '/modules/users/index.php/' . $id);
        } 
    }

    public function getUsers(){
        return UserModel::getAll();
    }

    public function delete($params){
        $request = Request::createFromGlobals();
        $id = $request->request->get('id');
        if($id){
            // $flashes = $this->session->getFlashBag();
            // // add flash messages
            // $flashes->add(
            //     'success',
            //     'Record successfully deleted'
            // );
            echo json_encode(array('success' => UserModel::delete($id)));
        }
    }

    private function _validateData($data){
        require __DIR__ . '/../../../../config/connection.php';
        $validator = new Validator;
        $validator->addValidator('unique', new UniqueRule($con));

        $validation = $validator->make($data, [
            'firstname' => 'required|min:3',
            'lastname' => 'required|min:3',
            'email' => 'required|min:3|email|unique:invoice_user,email',
            'phone' => 'required|min:1',
            'address' => 'required|min:1',
            'designation' => 'required|min:1',
            'role' => 'required',
            'zone_id' => 'required',
            'status' => 'required',
            
        ]);
        $validation->setAlias('firstname', 'First Name');
        $validation->setAlias('lastname', 'Last Name');
        $validation->setAlias('email', 'Email');
        $validation->setAlias('phone', 'Phone');
        $validation->setAlias('address', 'Address');
        $validation->setAlias('designation', 'Designation');
        $validation->setAlias('role', 'Role');
        $validation->setAlias('zone_id', 'Zone');
        $validation->setAlias('status', 'isAdmin');
        
        $validation->validate();

        return $validation;
    }

    private function _validateDataToUpdate($data){
        require __DIR__ . '/../../../../config/connection.php';
        $validator = new Validator;
        $validator->addValidator('unique', new UniqueRule($con));

        $validation = $validator->make($data, [
            'firstname' => 'required|min:3',
            'lastname' => 'required|min:3',
            'phone' => 'required|min:1',
            'address' => 'required|min:1',
            'designation' => 'required|min:1',
            'role' => 'required',
            'status' => 'required',
            
        ]);
        $validation->setAlias('firstname', 'First Name');
        $validation->setAlias('lastname', 'Last Name');
        $validation->setAlias('email', 'Email');
        $validation->setAlias('phone', 'Phone');
        $validation->setAlias('address', 'Address');
        $validation->setAlias('designation', 'Designation');
        $validation->setAlias('role', 'Role');
        $validation->setAlias('zone_id', 'Zone');
        $validation->setAlias('status', 'isAdmin');
        
        $validation->validate();

        return $validation;
    }
}
