<?php

namespace Se7entech\Contractnew\Modules\Users\Models;
use Se7entech\Contractnew\Helpers\EscapeString;

class UserModel{
    private static $table = 'invoice_user';

    public static function postUser($data){
        include __DIR__ . '/../../../../config/connection.php';
        $data = EscapeString::escapeArray($con, $data);

        $sql = "INSERT INTO " . self::$table ." (first_name, last_name, email, password, mobile, address, designation, role, zone_id, smtp_user, smtp_pass, avatar, status) VALUES ('".$data['firstname']."','".$data['lastname']."', '" . $data['email'] . "', '" . $data['password'] . "', '" . $data['phone'] . "', '" . $data['address'] . "', '" . $data['designation'] . "', '" . $data['role'] . "', '" . $data['zone_id'] . "', '" . $data['smtp_user'] . "', '" . $data['smtp_pass'] . "', '" . $data['avatar'] . "', '" . $data['status'] . "')";
        
        return(mysqli_query($con, $sql));
    }

    public static function getAll(){
        include __DIR__ . '/../../../../config/connection.php';
        $response = array();
        $sql = "SELECT * FROM " . self::$table;

        $res = mysqli_query($con, $sql);
        if(mysqli_num_rows($res)){
            while($row = mysqli_fetch_assoc($res)){
                array_push($response, $row);
            }
        }
        
        return $response;
    }

    public static function getById($id){
        include __DIR__ . '/../../../../config/connection.php';
        $response = array();
        $sql = "SELECT * FROM " . self::$table . " WHERE id=$id";

        $res = mysqli_query($con, $sql);
        if(mysqli_num_rows($res)){
            return mysqli_fetch_assoc($res);
        }
        
        return false;
    }

    public static function getByEmail($email){
        include __DIR__ . '/../../../../config/connection.php';
        $response = array();
        $sql = "SELECT email, first_name, last_name FROM " . self::$table . " WHERE email='$email'";

        $res = mysqli_query($con, $sql);
        if(mysqli_num_rows($res)){
            return mysqli_fetch_assoc($res);
        }
        
        return false;
    }

    public static function update($id, $data){
        include __DIR__ . '/../../../../config/connection.php';
        $data = EscapeString::escapeArray($con, $data);
        
        $sql = "UPDATE " . self::$table . " SET first_name='" . $data['firstname'] . "', last_name='" . $data['lastname'] . "',  mobile='" . $data['phone'] . "', address='" . $data['address'] . "', designation='" . $data['designation'] . "', role='" . $data['role'] . "', zone_id='" . $data['zone_id'] . "', status='" . $data['status'] . "', smtp_user='" . $data['smtp_user'] . "', smtp_pass='" . $data['smtp_pass'] . "', avatar='" . $data['avatar'] . "' WHERE id=$id";
        return(mysqli_query($con, $sql));
    }

    public static function delete($id){
        include __DIR__ . '/../../../../config/connection.php';

        $sql = "DELETE FROM " . self::$table . " WHERE id=$id";
        $res = mysqli_query($con, $sql);
        return $res;
    }
}